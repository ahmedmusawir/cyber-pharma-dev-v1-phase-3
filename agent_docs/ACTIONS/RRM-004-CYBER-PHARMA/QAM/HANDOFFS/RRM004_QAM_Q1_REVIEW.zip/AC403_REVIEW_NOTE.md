# AC-403 review note — export-only, no adjudication

Module: RRM-004-CYBER-PHARMA. Q1-C01 / stop Q4 remains unresolved. Prepared 2026-10-01T15:17:52+06:00 (Asia/Dhaka (UTC+06:00)). Original reports and contract are unchanged. This note supplies additional recorded authorization context; it does not waive AC-403 or issue a grade.

## Exact frozen criterion

The row below is copied verbatim from the product candidate's ACCEPTANCE_SPEC.md and matches the current original row (line 47):

| AC-403 | `git diff --name-only <baseline>` lists only: `package.json`, `package-lock.json`, `next.config.js`, files under `agent_docs/ACTIONS/RRM-004-CYBER-PHARMA/`, the ledger/map lines instructed at handoff, and root-protocol files. `node_modules/` never appears in `git status`. | repo | `evidence/changed_files.txt` |

Baseline: `649c36d0409c0b658cff14f779a09aad0c8e92b9`. Product candidate: `2fbc72f1f514049255f2b94054bd11cc77cbd158`. QA HEAD: `5362b79ca724e454011e77aeaf4b11101176d0b5`.

## Applicable authority and its limits

- RULINGS_ADDENDUM.md A-05 changes the transitive sweep policy and names AC-403; it does not enumerate an exception for the earlier closeout-document paths.
- A-09 relocates QA paths to QAM; A-10–A-14 govern credentials, authorship, phases and Q1 permissions. They support comparison B/QAM artifacts; no row explicitly adjudicates this AC-403 baseline-diff question.
- CLAUDY_PROMPTS.md §P0 (lines 9–11 and 44) explicitly authorizes the campaign-journal and RRM-003 closeout fields. It remains part of the frozen pack.
- Root CLAUDE.md supplies response/session/recovery/change-log protocols. QAM/AGENTS.md supplies QA artifact permissions and Q4; it is not a product-scope waiver.
- GOVERNING/WEB_FACTORY_P1_DOCTRINE_JOURNAL.md J-04/J-20/J-21 preserves frozen AC text and records rulings separately; J-09 permits Director archival of response records.

## A. Baseline → engineering product candidate

See EXPORT_EVIDENCE/A_baseline_to_candidate.txt for the complete path/status list and AC403_authorization_and_diff.txt for safe excerpts. The candidate contains product changes plus pre-candidate documentation commits. The five paths below are the paths that triggered Q1-C01; none first appeared as a Q1 uncommitted edit.

| Triggering repository path | Change and provenance | Recorded authorization | What remains for the QA Lead/Architect |
|---|---|---|---|
| agent_docs/ACTIONS/RRM-002-CYBER-PHARMA/EXECUTION_LOG.md | Fill closeout/merge SHAs; a93393d | Archived 2026-09-30 12:39:54 SHA-record plan, item 2; session_2026-09-30.md 12:46 APPROVED entry records Director “go”; 12:47 completion and archived result corroborate | How this authorized predecessor change is graded under AC-403's literal path list |
| agent_docs/ACTIONS/RRM-002-CYBER-PHARMA/README.md | Fill closeout/merge SHAs; a93393d | Same plan item 2 and recorded approval | Same unresolved AC-403 coverage question |
| agent_docs/ACTIONS/RRM-003-CYBER-PHARMA/EXECUTION_LOG.md | Fill closeout/merge SHAs; a93393d | Same plan item 1 and recorded approval; additionally CLAUDY_PROMPTS.md §P0 step 4; P0 result says this was already done | Same unresolved AC-403 coverage question |
| agent_docs/ACTIONS/RRM-003-CYBER-PHARMA/README.md | Add merged-to-main suffix; ee4a049 | CLAUDY_PROMPTS.md §P0 step 4; session 15:09 approval/15:18 completion and P0 result | Same unresolved AC-403 coverage question |
| agent_docs/RRM_CAMPAIGN_JOURNAL.md | Architect entry and friction log; ee4a049 | CLAUDY_PROMPTS.md §P0 step 1; session 15:09 approval/15:18 completion and P0 result | Same unresolved AC-403 coverage question |

**Authorization distinction:** all five now have an explicit recorded editing instruction and an approval record available in this package. That record is not an Executor adjudication of the AC. The RRM-002 authorization is outside the P0 text and was located for this export through the archived plan/session. It must not be described simply as an unauthorized product change, nor silently treated as an AC-403 exception. The actual source/contract grade remains for the QA Lead/Architect.

The same A comparison includes root-protocol records and response archives. Commit 1eb9c04 moves twelve response files into RESPONSES/_OLD without changing their contents; exact original and destination names are in the transcript. General archive authority is J-09 and the manifest identifies this move. No separate per-file archival instruction was located in the selected records; whether root-protocol coverage suffices is a review point, not a new waiver. Ledger/map paths and CHANGELOG/RECOVERY/session/response records must retain their own authorization basis, rather than receiving a blanket agent_docs exception.

## B. Product candidate → current QA HEAD

See EXPORT_EVIDENCE/B_candidate_to_qa_head.txt. This committed span contains the QA→QAM overlay, P2b errata, Q1 ratification and session update. The recorded product/protected-path stat is empty. A-09–A-14 provide the QAM rule/rename context. These successor changes are distinct from the pre-candidate closeout changes in A and from current dirty outputs in C; documentation-only successor status does not itself adjudicate A's AC-403 grade.

## C. Uncommitted QA outputs

See EXPORT_EVIDENCE/C_uncommitted_at_export.txt and each FILE_INDEX.json working_copy_status. The two tracked changes are QAM_TEST_PLAN.md (DRAFT) and QAM_EXECUTION_REPORT.md (Q1 report). The untracked prior Q1 artifacts are the two helpers, eight evidence files, both required response records and the Executor's session log. They are authorized QA output locations under QAM/AGENTS.md and A-14. Export work artifacts under HANDOFFS are newly authorized by the Director's export-only instruction and are labeled separately. None belongs to comparison B's committed HEAD diff. No inference of a dirty original Q1 entry gate follows from today's export state.

## Exact decision requested

1. Rule whether the five documented predecessor closeout/journal edits satisfy the frozen AC-403 scope under the recorded authorizations, require an explicit append-only erratum naming allowed paths/provenance, or require another bounded disposition. Also clarify response-archive/root-protocol treatment as needed. Preserve the baseline and product-path protections; do not infer a blanket docs exemption.
2. State the disposition of Q1-C01/Q4 and route any contract/addendum amendment to the Engineer. The Executor does not edit the frozen criterion or make that decision.
3. Review/amend QAM_TEST_PLAN.md and supply the QA Lead approval line/date before Q1b and a later Director Q2 command. Q1 preflight evidence is available for verification; Q2/product certification remain NOT RUN/pending.
