# Start here — RRM-004 Q1 review export

- Module: RRM-004-CYBER-PHARMA — Dependencies / QAM pilot.
- Checkpoint: Q1 recon review and Q2 test-plan approval; Q4/Q1-C01 is open.
- Attempt: original Q1 attempt 1; export revision 1. This is an export, not a Q1 rerun or a Q4 retest.
- Export prepared: 2026-10-01T15:17:52+06:00; timezone Asia/Dhaka (UTC+06:00).
- Branch: `qa/phase-3-rrm004`.
- Baseline: `649c36d0409c0b658cff14f779a09aad0c8e92b9`.
- Engineering product candidate: `2fbc72f1f514049255f2b94054bd11cc77cbd158`.
- QA HEAD: `5362b79ca724e454011e77aeaf4b11101176d0b5`.
- Test plan: **DRAFT / awaiting QA Lead approval**. No plan approval or certification is issued here.

## Working copies and status

Current working copies are used, with original bytes retained. At export intake there are two tracked modifications (QAM_TEST_PLAN.md and QAM_EXECUTION_REPORT.md) and thirteen untracked prior-Q1 files (two helpers, eight evidence records, two responses and one session log). None is staged. Export-only files are created separately under QAM/evidence/HANDOFFS. C_uncommitted_at_export.txt captures the status during export preparation, including any new packaging files; the index labels each original file's status.

The AC_EVIDENCE_MATRIX.md and QAM_PILOT_RESULTS.md are **scaffolds with unfilled fields**. QAM_EXECUTION_REPORT.md is a Q1 report, not a completed Q2 body. The draft's proposed checks and example expected values are plans, not measured Q2 results. Placeholders have not been filled for packaging. Historical QA/ paths in frozen originals remain unchanged; apply A-09's QAM mapping when reading them. Some original response links are absolute workspace paths: resolve their agent_docs suffix to the matching repository-relative archive member.

## What ran, and what remains NOT RUN

**QA observations already recorded:** Q1 preflight reports 18/18 PASS with an independent install and real-target build; QF-16 reports ADMIN 1 / MEMBER 1 sign-in, each protected route 200, logout success and subsequent 307→/auth; Q1 shutdown/profile-removal and privacy results are included. The Q1 scanner self-test and helper corrections are historical evidence, not rerun by this export. Q1 recon found Q1-C01 and stopped at Q4.

**Engineering claims:** module EXECUTION_LOG.md, QA_HANDOFF.md, QAM_MANIFEST.md and module/evidence describe engineering builds, tests, audits and served probes. Their inclusion does not convert them into independent QA results.

**Governing rulings:** ACCEPTANCE_SPEC.md plus its erratum lane, RULINGS_ADDENDUM.md A-01–A-14, ratified QAM instructions and supplied governing snapshots determine scope. Export notes do not amend them.

**NOT RUN in this export:** Q1 gate/build/browser/tests, Q2 body, product repairs, Q1b amendments, retest, Q5 credential cleanup and certification. Only file selection/copying, hashes, permitted read-only Git inspection, ZIP verification and export privacy checks are performed. .env.qa.local remains available locally and is excluded.

## Decisions requested

- Verify the reported Q1 gate and authentication/privacy evidence.
- Adjudicate Q1-C01/AC-403 using AC403_REVIEW_NOTE.md, including the distinction between authorization of earlier edits and their treatment under the criterion. State Q4's disposition and any Engineer-owned append-only contract amendment.
- Review/amend the draft test plan and provide an explicit QA Lead approval line/date. Q1b and a later Q2 command remain separate checkpoints.

## Suggested reading order

1. This file, then AC403_REVIEW_NOTE.md.
2. Both required Q1 responses in agent_docs/RESPONSES/ (13:49:27 recon and 14:38:40 handoff recommendation).
3. QAM/QAM_EXECUTION_REPORT.md and QAM/QAM_TEST_PLAN.md.
4. Module ACCEPTANCE_SPEC.md, RULINGS_ADDENDUM.md and CLAUDY_PROMPTS.md §P0; the archived SHA-recording plan and session_2026-09-30.md approval entries.
5. EXPORT_EVIDENCE comparisons A, B, C and safe authorization/diff excerpts.
6. QAM/evidence/QAM_PREFLIGHT_Q1.txt, entry_gate.json, recon.txt, qf16_result.json, qf16_server.txt, temp_paths.json, q1_final_checks.txt and original privacy_audit.json; both original helper sources.
7. QAM risk requirements/manifest/governing snapshots, then engineering evidence as needed.
8. FILE_INDEX.json and EXPORT_EVIDENCE/selected_privacy_check.json. The final released-ZIP verification and hash are reported separately beside the ZIP.

## Inclusion, missing items and exclusions

FILE_INDEX.json is the explicit membership list, with source path, purpose, SHA-256, size and working-copy status for each member except itself. Original files retain repository-relative paths. Newly authored export-only review notes/index sit at the archive root; new safe transcripts/helper/check results sit under EXPORT_EVIDENCE and have no original repository path. No recursive archive of the repository is used.

Required/selected files missing: None.

Root AGENTS.md: No repository-root AGENTS.md exists; conditional item not applicable. The applicable QAM/AGENTS.md is included.

Intentionally absent: all environment files and backups, credential values, cookies/auth state, browser profiles, raw authenticated traces, node_modules, .next/generated builds, Git internals, binaries/image response bodies, other ZIPs and staging directories. Q2/Q5/certification artifacts are not fabricated. Historical references to removed environment/profile paths do not mean those files are included. Prior-module evidence unrelated to the scope decision is not recursively copied; the needed current records and safe excerpts are supplied.

## Privacy and integrity method

The existing privacy_scan.cjs is reused byte-for-byte. An export-only wrapper changes only its filesystem root/process view in an isolated VM so it scans a selected-copy mirror and writes a new audit there, never overwriting original Q1 evidence. No QF-17 self-test is rerun. Both values and patterns modes run on selected copies; the final ZIP is separately scanned with the same scanner's ZIP-entry expansion before release. Credentials are loaded via Node's env-file flag and held only in the local scanner process. The original evidence privacy_audit.json remains historical and unchanged. See the wrapper source for the path-only adaptation.

Release requires clean final scans, ZIP CRC verification, exact membership/index correspondence, per-file SHA-256 matches, excluded-path/nested-archive checks, unchanged input hashes and unchanged QA HEAD. The separate release verification report records actual outcomes; this paragraph states the release procedure, not a prospective PASS.
